package com.college.placement;

import com.college.placement.dto.ApplicationStatusUpdateDto;
import com.college.placement.dto.EligibilityResultDto;
import com.college.placement.entity.*;
import com.college.placement.exception.*;
import com.college.placement.repository.JobApplicationRepository;
import com.college.placement.service.JobApplicationService;
import com.college.placement.service.JobPostingService;
import com.college.placement.service.StudentProfileService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("Job Application Workflow & State Machine Tests")
class JobApplicationServiceTest {

    private JobApplicationRepository applicationRepository;
    private JobPostingService jobPostingService;
    private StudentProfileService studentProfileService;
    private JobApplicationService applicationService;

    @BeforeEach
    void setUp() {
        applicationRepository = Mockito.mock(JobApplicationRepository.class);
        jobPostingService = Mockito.mock(JobPostingService.class);
        studentProfileService = Mockito.mock(StudentProfileService.class);
        applicationService = new JobApplicationService(applicationRepository, jobPostingService, studentProfileService);
    }

    @Test
    @DisplayName("Should prevent duplicate applications to the same job drive")
    void testDuplicateApplicationPrevention() {
        String studentEmail = "rahul.cse@college.edu";
        Long jobId = 10L;

        StudentProfile student = new StudentProfile();
        student.setId(1L);
        JobPosting job = new JobPosting();
        job.setId(jobId);
        job.setTitle("Cloud Engineer");
        job.setCompany(new Company("AWS", "Cloud", "Bangalore", "https://aws.com"));

        when(studentProfileService.getProfileByEmail(studentEmail)).thenReturn(student);
        when(jobPostingService.getJobById(jobId)).thenReturn(job);
        // Simulate already applied
        when(applicationRepository.existsByStudentIdAndJobPostingId(1L, jobId)).thenReturn(true);

        assertThrows(DuplicateApplicationException.class, () -> {
            applicationService.applyToJob(studentEmail, jobId, "Duplicate attempt");
        }, "Should throw DuplicateApplicationException when student applies twice to the same job");

        verify(applicationRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should reject application submission if student fails eligibility check")
    void testIneligibleApplicationRejection() {
        String studentEmail = "student@college.edu";
        Long jobId = 20L;

        StudentProfile student = new StudentProfile();
        student.setId(2L);
        JobPosting job = new JobPosting();
        job.setId(jobId);

        when(studentProfileService.getProfileByEmail(studentEmail)).thenReturn(student);
        when(jobPostingService.getJobById(jobId)).thenReturn(job);
        when(applicationRepository.existsByStudentIdAndJobPostingId(2L, jobId)).thenReturn(false);
        when(jobPostingService.checkEligibility(student, job))
                .thenReturn(EligibilityResultDto.ineligible("CGPA does not meet requirement"));

        assertThrows(IneligibleApplicationException.class, () -> {
            applicationService.applyToJob(studentEmail, jobId, "Applying anyway");
        }, "Should block application and throw IneligibleApplicationException");

        verify(applicationRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should allow status transition from APPLIED to SHORTLISTED and then SELECTED")
    void testValidStatusTransition() {
        Long appId = 100L;
        JobApplication app = new JobApplication();
        app.setId(appId);
        app.setStatus(ApplicationStatus.APPLIED);

        when(applicationRepository.findById(appId)).thenReturn(Optional.of(app));
        when(applicationRepository.save(any(JobApplication.class))).thenAnswer(i -> i.getArgument(0));

        // 1. Transition to SHORTLISTED
        ApplicationStatusUpdateDto shortlistDto = new ApplicationStatusUpdateDto(ApplicationStatus.SHORTLISTED, "Cleared round 1");
        shortlistDto.setInterviewRoundsCleared(1);
        JobApplication updated = applicationService.updateApplicationStatus(appId, shortlistDto);
        assertEquals(ApplicationStatus.SHORTLISTED, updated.getStatus());
        assertEquals(1, updated.getInterviewRoundsCleared());

        // 2. Transition to SELECTED
        ApplicationStatusUpdateDto selectDto = new ApplicationStatusUpdateDto(ApplicationStatus.SELECTED, "Offer extended");
        selectDto.setInterviewRoundsCleared(3);
        JobApplication finalApp = applicationService.updateApplicationStatus(appId, selectDto);
        assertEquals(ApplicationStatus.SELECTED, finalApp.getStatus());
    }

    @Test
    @DisplayName("Should forbid resetting a SELECTED applicant directly to APPLIED")
    void testInvalidStatusTransitionFromSelectedToApplied() {
        Long appId = 200L;
        JobApplication app = new JobApplication();
        app.setId(appId);
        app.setStatus(ApplicationStatus.SELECTED);

        when(applicationRepository.findById(appId)).thenReturn(Optional.of(app));

        ApplicationStatusUpdateDto invalidDto = new ApplicationStatusUpdateDto(ApplicationStatus.APPLIED, "Resetting");

        assertThrows(InvalidStatusTransitionException.class, () -> {
            applicationService.updateApplicationStatus(appId, invalidDto);
        }, "Should throw InvalidStatusTransitionException when resetting Selected back to Applied");
    }

    @Test
    @DisplayName("Should allow withdrawal only when status is APPLIED")
    void testWithdrawalRules() {
        String studentEmail = "rahul@college.edu";
        Long appId = 300L;

        User u = new User();
        u.setEmail(studentEmail);
        StudentProfile s = new StudentProfile();
        s.setUser(u);

        JobApplication app = new JobApplication();
        app.setId(appId);
        app.setStudent(s);
        app.setStatus(ApplicationStatus.SHORTLISTED); // Already shortlisted!

        when(applicationRepository.findById(appId)).thenReturn(Optional.of(app));

        assertThrows(InvalidStatusTransitionException.class, () -> {
            applicationService.withdrawApplication(studentEmail, appId);
        }, "Should not allow withdrawal once application is past APPLIED status");
    }
}
