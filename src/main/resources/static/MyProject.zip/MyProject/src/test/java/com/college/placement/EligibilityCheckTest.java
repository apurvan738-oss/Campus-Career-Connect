package com.college.placement;

import com.college.placement.dto.EligibilityResultDto;
import com.college.placement.entity.*;
import com.college.placement.service.CompanyService;
import com.college.placement.service.JobPostingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Student Eligibility Verification Tests")
class EligibilityCheckTest {

    private JobPostingService jobPostingService;

    @BeforeEach
    void setUp() {
        jobPostingService = new JobPostingService(null, Mockito.mock(CompanyService.class));
    }

    private StudentProfile createSampleStudent(String branch, Double cgpa, Integer gradYear, String resumeFile) {
        StudentProfile s = new StudentProfile();
        s.setFullName("Test Candidate");
        s.setRollNumber("2021TEST001");
        s.setBranch(branch);
        s.setCgpa(cgpa);
        s.setGraduationYear(gradYear);
        s.setResumeFileName(resumeFile);
        s.setPhone("9876543210");
        s.setSkills("Java, Spring, SQL");
        s.checkCompleteness();
        return s;
    }

    private JobPosting createSampleJob(Double minCgpa, String eligibleBranches, Integer gradYear, LocalDateTime deadline) {
        JobPosting job = new JobPosting();
        job.setTitle("Associate Software Engineer");
        job.setMinimumCgpa(minCgpa);
        job.setEligibleBranches(eligibleBranches);
        job.setGraduationYear(gradYear);
        job.setApplicationDeadline(deadline);
        job.setStatus(JobStatus.OPEN);
        job.setActive(true);
        return job;
    }

    @Test
    @DisplayName("Should approve candidate when all academic & deadline criteria are met")
    void testEligibleCandidate() {
        StudentProfile student = createSampleStudent("CSE", 8.5, 2025, "resume.pdf");
        JobPosting job = createSampleJob(7.0, "CSE, IT, ECE", 2025, LocalDateTime.now().plusDays(10));

        EligibilityResultDto result = jobPostingService.checkEligibility(student, job);

        assertTrue(result.isEligible(), "Candidate should be eligible");
        assertTrue(result.getReasons().isEmpty(), "There should be no rejection reasons");
    }

    @Test
    @DisplayName("Should reject candidate when CGPA is below cutoff")
    void testIneligibleDueToLowCgpa() {
        StudentProfile student = createSampleStudent("CSE", 6.8, 2025, "resume.pdf");
        JobPosting job = createSampleJob(7.5, "CSE, IT", 2025, LocalDateTime.now().plusDays(10));

        EligibilityResultDto result = jobPostingService.checkEligibility(student, job);

        assertFalse(result.isEligible(), "Candidate with low CGPA must be ineligible");
        assertTrue(result.getReasons().stream().anyMatch(r -> r.contains("CGPA")),
                "Reasons must explicitly detail CGPA deficiency");
    }

    @Test
    @DisplayName("Should reject candidate when branch is not in eligible list")
    void testIneligibleDueToBranchMismatch() {
        StudentProfile student = createSampleStudent("ME", 8.9, 2025, "resume.pdf");
        JobPosting job = createSampleJob(6.5, "CSE, IT, ECE", 2025, LocalDateTime.now().plusDays(10));

        EligibilityResultDto result = jobPostingService.checkEligibility(student, job);

        assertFalse(result.isEligible(), "Candidate from non-listed branch must be ineligible");
        assertTrue(result.getReasons().stream().anyMatch(r -> r.contains("branch")),
                "Reasons must explicitly mention branch ineligibility");
    }

    @Test
    @DisplayName("Should accept any branch when job eligibleBranches is set to 'ALL'")
    void testAllBranchesEligibility() {
        StudentProfile student = createSampleStudent("CIVIL", 8.0, 2025, "resume.pdf");
        JobPosting job = createSampleJob(6.0, "ALL", 2025, LocalDateTime.now().plusDays(5));

        EligibilityResultDto result = jobPostingService.checkEligibility(student, job);

        assertTrue(result.isEligible(), "Candidate should be eligible when branch criteria is ALL");
    }

    @Test
    @DisplayName("Should reject application when drive deadline has expired")
    void testIneligibleDueToPassedDeadline() {
        StudentProfile student = createSampleStudent("CSE", 9.0, 2025, "resume.pdf");
        JobPosting job = createSampleJob(7.0, "CSE", 2025, LocalDateTime.now().minusDays(1));

        EligibilityResultDto result = jobPostingService.checkEligibility(student, job);

        assertFalse(result.isEligible(), "Application after deadline must be rejected");
        assertTrue(result.getReasons().stream().anyMatch(r -> r.contains("deadline")),
                "Rejection reasons must detail expired deadline");
    }

    @Test
    @DisplayName("Should reject candidate who has not uploaded a resume")
    void testIneligibleWithoutResume() {
        StudentProfile student = createSampleStudent("CSE", 9.0, 2025, null);
        JobPosting job = createSampleJob(7.0, "CSE", 2025, LocalDateTime.now().plusDays(5));

        EligibilityResultDto result = jobPostingService.checkEligibility(student, job);

        assertFalse(result.isEligible(), "Candidate without uploaded resume must be ineligible");
        assertTrue(result.getReasons().stream().anyMatch(r -> r.toLowerCase().contains("resume")),
                "Rejection reasons must prompt student to upload resume");
    }
}
