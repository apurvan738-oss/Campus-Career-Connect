package com.college.placement;

import com.college.placement.dto.UserRegistrationDto;
import com.college.placement.entity.Role;
import com.college.placement.entity.User;
import com.college.placement.repository.StudentProfileRepository;
import com.college.placement.repository.UserRepository;
import com.college.placement.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("Role-Based Security & Registration Tests")
class RoleAuthorizationTest {

    private UserRepository userRepository;
    private StudentProfileRepository profileRepository;
    private PasswordEncoder passwordEncoder;
    private UserService userService;

    @BeforeEach
    void setUp() {
        userRepository = Mockito.mock(UserRepository.class);
        profileRepository = Mockito.mock(StudentProfileRepository.class);
        passwordEncoder = new BCryptPasswordEncoder();
        userService = new UserService(userRepository, profileRepository, passwordEncoder);
    }

    @Test
    @DisplayName("Public student registration must enforce ROLE_STUDENT and never create admin/officer")
    void testRegistrationEnforcesStudentRole() {
        UserRegistrationDto dto = new UserRegistrationDto();
        dto.setFullName("Ananya Sen");
        dto.setEmail("ananya.ece@college.edu");
        dto.setRollNumber("2021BECE088");
        dto.setBranch("ECE");
        dto.setGraduationYear(2025);
        dto.setCgpa(8.2);
        dto.setPhone("9876543210");
        dto.setPassword("SecurePass123");
        dto.setConfirmPassword("SecurePass123");

        when(userRepository.existsByEmailIgnoreCase(any())).thenReturn(false);
        when(profileRepository.existsByRollNumberIgnoreCase(any())).thenReturn(false);
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        User registeredUser = userService.registerStudent(dto);

        assertNotNull(registeredUser);
        assertEquals(Role.STUDENT, registeredUser.getRole(), "Public registration must strictly assign Role.STUDENT");
        assertNotEquals("SecurePass123", registeredUser.getPassword(), "Plaintext password must never be stored");
        assertTrue(passwordEncoder.matches("SecurePass123", registeredUser.getPassword()), "BCrypt hash must match original password");
    }

    @Test
    @DisplayName("Registration must reject when email already exists")
    void testDuplicateEmailRejected() {
        UserRegistrationDto dto = new UserRegistrationDto();
        dto.setEmail("existing@college.edu");
        dto.setPassword("Pass123");
        dto.setConfirmPassword("Pass123");

        when(userRepository.existsByEmailIgnoreCase("existing@college.edu")).thenReturn(true);

        assertThrows(IllegalArgumentException.class, () -> {
            userService.registerStudent(dto);
        }, "Should throw IllegalArgumentException if email is already taken");
    }
}
